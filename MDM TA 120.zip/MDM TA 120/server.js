const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const db = new Database(path.join(__dirname, 'hotel.db'));
db.pragma('foreign_keys = ON');

// ---------- Schema ----------
db.exec(`
CREATE TABLE IF NOT EXISTS rooms (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  room_no TEXT NOT NULL UNIQUE,
  type    TEXT NOT NULL,
  price   REAL NOT NULL CHECK (price > 0)
);
CREATE TABLE IF NOT EXISTS bookings (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id    INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  guest_name TEXT NOT NULL,
  check_in   TEXT NOT NULL,   -- YYYY-MM-DD
  check_out  TEXT NOT NULL    -- YYYY-MM-DD
);`);

// ---------- Middleware ----------
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Helpers ----------
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s));

// Two stays overlap if: existing.check_in < new.check_out AND existing.check_out > new.check_in
const overlaps = (roomId, checkIn, checkOut, ignoreBookingId = 0) =>
  db.prepare(`SELECT 1 FROM bookings
              WHERE room_id = ? AND id != ? AND check_in < ? AND check_out > ?`)
    .get(roomId, ignoreBookingId, checkOut, checkIn);

// ---------- Rooms ----------
// Add a new room (POST)
app.post('/api/rooms', (req, res) => {
  const { room_no, type, price } = req.body;
  if (!room_no || !type || !(Number(price) > 0))
    return res.status(400).json({ error: 'room_no, type and a positive price are required' });
  try {
    const r = db.prepare('INSERT INTO rooms (room_no, type, price) VALUES (?,?,?)')
      .run(String(room_no).trim(), String(type).trim(), Number(price));
    res.status(201).json({ id: r.lastInsertRowid });
  } catch (e) {
    if (String(e.message).includes('UNIQUE'))
      return res.status(409).json({ error: 'Room number already exists' });
    res.status(500).json({ error: e.message });
  }
});

// List all rooms with today's availability status (GET)
app.get('/api/rooms', (req, res) => {
  const rows = db.prepare(`
    SELECT r.*,
      CASE WHEN EXISTS (SELECT 1 FROM bookings b
                        WHERE b.room_id = r.id
                          AND date('now') >= b.check_in AND date('now') < b.check_out)
           THEN 'Booked' ELSE 'Available' END AS status
    FROM rooms r ORDER BY r.room_no`).all();
  res.json(rows);
});

// Search available rooms by type and/or date range (GET)
app.get('/api/rooms/search', (req, res) => {
  const { type, checkIn, checkOut } = req.query;
  if ((checkIn || checkOut) && !(isDate(checkIn) && isDate(checkOut) && checkIn < checkOut))
    return res.status(400).json({ error: 'Provide valid checkIn and checkOut (checkIn must be before checkOut)' });

  let sql = 'SELECT * FROM rooms WHERE 1=1';
  const params = [];
  if (type) { sql += ' AND LOWER(type) = LOWER(?)'; params.push(type); }
  if (checkIn && checkOut) {
    sql += ` AND id NOT IN (SELECT room_id FROM bookings WHERE check_in < ? AND check_out > ?)`;
    params.push(checkOut, checkIn);
  }
  res.json(db.prepare(sql + ' ORDER BY room_no').all(...params));
});

// ---------- Bookings ----------
// List bookings (GET)
app.get('/api/bookings', (req, res) => {
  res.json(db.prepare(`
    SELECT b.*, r.room_no, r.type, r.price
    FROM bookings b JOIN rooms r ON r.id = b.room_id
    ORDER BY b.check_in`).all());
});

// Book a room (POST)
app.post('/api/bookings', (req, res) => {
  const { room_id, guest_name, check_in, check_out } = req.body;
  if (!room_id || !guest_name || !String(guest_name).trim())
    return res.status(400).json({ error: 'room_id and guest_name are required' });
  if (!isDate(check_in) || !isDate(check_out) || check_in >= check_out)
    return res.status(400).json({ error: 'Valid dates required; check-out must be after check-in' });
  if (!db.prepare('SELECT 1 FROM rooms WHERE id = ?').get(room_id))
    return res.status(404).json({ error: 'Room not found' });
  if (overlaps(room_id, check_in, check_out))
    return res.status(409).json({ error: 'Room is already booked for these dates' });

  const r = db.prepare('INSERT INTO bookings (room_id, guest_name, check_in, check_out) VALUES (?,?,?,?)')
    .run(room_id, String(guest_name).trim(), check_in, check_out);
  res.status(201).json({ id: r.lastInsertRowid });
});

// Change booking dates (PUT)
app.put('/api/bookings/:id', (req, res) => {
  const { check_in, check_out } = req.body;
  const b = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!b) return res.status(404).json({ error: 'Booking not found' });
  if (!isDate(check_in) || !isDate(check_out) || check_in >= check_out)
    return res.status(400).json({ error: 'Valid dates required; check-out must be after check-in' });
  if (overlaps(b.room_id, check_in, check_out, b.id))
    return res.status(409).json({ error: 'Room is already booked for these dates' });
  db.prepare('UPDATE bookings SET check_in = ?, check_out = ? WHERE id = ?').run(check_in, check_out, b.id);
  res.json({ message: 'Booking updated' });
});

// Cancel a booking (DELETE)
app.delete('/api/bookings/:id', (req, res) => {
  const r = db.prepare('DELETE FROM bookings WHERE id = ?').run(req.params.id);
  if (r.changes === 0) return res.status(404).json({ error: 'Booking not found' });
  res.json({ message: 'Booking cancelled' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Hotel booking running at http://localhost:${PORT}`));
