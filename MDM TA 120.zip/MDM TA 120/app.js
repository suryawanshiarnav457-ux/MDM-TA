const $ = (id) => document.getElementById(id);

function show(text, ok = true) {
  const m = $('msg');
  m.textContent = text;
  m.className = ok ? 'ok' : 'err';
}

// Wrapper around fetch: sends/receives JSON and throws the server's error message
async function api(url, method = 'GET', body) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// Build a table row safely (textContent avoids HTML injection)
function row(cells, extra) {
  const tr = document.createElement('tr');
  cells.forEach(([text, cls]) => {
    const td = document.createElement('td');
    td.textContent = text;
    if (cls) td.className = cls;
    tr.appendChild(td);
  });
  if (extra) { const td = document.createElement('td'); td.appendChild(extra); tr.appendChild(td); }
  return tr;
}

// ---------- Rooms ----------
let allRooms = [];

function renderRooms(rooms, withStatus = true) {
  const body = $('roomsBody');
  body.innerHTML = '';
  rooms.forEach(r => body.appendChild(row([
    [r.room_no], [r.type], ['₹' + r.price],
    [withStatus ? r.status : 'Available for selected dates', withStatus ? r.status : 'Available']
  ])));
  if (!rooms.length) body.innerHTML = '<tr><td colspan="4">No rooms found</td></tr>';
}

async function loadRooms() {
  allRooms = await api('/api/rooms');
  renderRooms(allRooms);
  $('roomsTitle').textContent = 'Rooms';
  const sel = $('bRoom');
  sel.innerHTML = '';
  allRooms.forEach(r => sel.add(new Option(`${r.room_no} — ${r.type} (₹${r.price})`, r.id)));
}

// ---------- Bookings ----------
async function loadBookings() {
  const list = await api('/api/bookings');
  const body = $('bookingsBody');
  body.innerHTML = '';
  list.forEach(b => {
    const btn = document.createElement('button');
    btn.textContent = 'Cancel';
    btn.className = 'danger';
    btn.onclick = () => cancelBooking(b.id);
    body.appendChild(row([[`${b.room_no} (${b.type})`], [b.guest_name], [b.check_in], [b.check_out]], btn));
  });
  if (!list.length) body.innerHTML = '<tr><td colspan="5">No bookings yet</td></tr>';
}

async function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  try {
    const r = await api('/api/bookings/' + id, 'DELETE');
    show(r.message);
    await refresh();
  } catch (e) { show(e.message, false); }
}

async function refresh() { await loadRooms(); await loadBookings(); }

// ---------- Events ----------
$('roomForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    await api('/api/rooms', 'POST', {
      room_no: $('roomNo').value, type: $('roomType').value, price: $('roomPrice').value
    });
    show('Room added');
    e.target.reset();
    await refresh();
  } catch (err) { show(err.message, false); }
};

$('bookForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    await api('/api/bookings', 'POST', {
      room_id: Number($('bRoom').value), guest_name: $('bGuest').value,
      check_in: $('bIn').value, check_out: $('bOut').value
    });
    show('Room booked');
    e.target.reset();
    await refresh();
  } catch (err) { show(err.message, false); }
};

$('searchForm').onsubmit = async (e) => {
  e.preventDefault();
  const q = new URLSearchParams();
  if ($('sType').value) q.set('type', $('sType').value);
  if ($('sIn').value) q.set('checkIn', $('sIn').value);
  if ($('sOut').value) q.set('checkOut', $('sOut').value);
  try {
    const rooms = await api('/api/rooms/search?' + q);
    const dated = $('sIn').value && $('sOut').value;
    renderRooms(rooms, false);
    $('roomsTitle').textContent = `Search results (${rooms.length})`;
    show(dated ? 'Showing rooms free for those dates' : 'Showing rooms by type');
  } catch (err) { show(err.message, false); }
};

$('clearSearch').onclick = () => { $('searchForm').reset(); show(''); loadRooms(); };

refresh().catch(err => show(err.message, false));
